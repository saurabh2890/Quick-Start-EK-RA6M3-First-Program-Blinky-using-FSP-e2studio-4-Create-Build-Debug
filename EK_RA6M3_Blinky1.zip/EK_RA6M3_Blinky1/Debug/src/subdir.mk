################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../src/hal_entry.c \
../src/hal_warmstart.c 

C_DEPS += \
./src/hal_entry.d \
./src/hal_warmstart.d 

OBJS += \
./src/hal_entry.o \
./src/hal_warmstart.o 

SREC += \
EK_RA6M3_Blinky1.srec 

MAP += \
EK_RA6M3_Blinky1.map 


# Each subdirectory must supply rules for building sources it contributes
src/%.o: ../src/%.c
	$(file > $@.in,-mcpu=cortex-m4 -mthumb -mfloat-abi=hard -mfpu=fpv4-sp-d16 -O2 -fmessage-length=0 -fsigned-char -ffunction-sections -fdata-sections -fno-strict-aliasing -Wunused -Wuninitialized -Wall -Wextra -Wmissing-declarations -Wconversion -Wpointer-arith -Wshadow -Wlogical-op -Waggregate-return -Wfloat-equal -g -D_RENESAS_RA_ -D_RA_CORE=CM4 -D_RA_ORDINAL=1 -I"C:/Renesas/e2_2512_latest/EK_RA6M3_Blinky1/ra_gen" -I"." -I"C:/Renesas/e2_2512_latest/EK_RA6M3_Blinky1/ra_cfg/fsp_cfg/bsp" -I"C:/Renesas/e2_2512_latest/EK_RA6M3_Blinky1/ra_cfg/fsp_cfg" -I"C:/Renesas/e2_2512_latest/EK_RA6M3_Blinky1/src" -I"C:/Renesas/e2_2512_latest/EK_RA6M3_Blinky1/ra/fsp/inc" -I"C:/Renesas/e2_2512_latest/EK_RA6M3_Blinky1/ra/fsp/inc/api" -I"C:/Renesas/e2_2512_latest/EK_RA6M3_Blinky1/ra/fsp/inc/instances" -I"C:/Renesas/e2_2512_latest/EK_RA6M3_Blinky1/ra/arm/CMSIS_6/CMSIS/Core/Include" -std=c99 -Wno-stringop-overflow -Wno-format-truncation --param=min-pagesize=0 -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -c -o "$@" -x c "$<")
	@echo Building file: $< && arm-none-eabi-gcc @"$@.in"

